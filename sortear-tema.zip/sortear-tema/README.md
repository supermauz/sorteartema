# Sortear tema

A Pen created on CodePen.io. Original URL: [https://codepen.io/supermauz/pen/BaVayGw](https://codepen.io/supermauz/pen/BaVayGw).

Um micro código para sortear temas de estudo para o dia. Utilizando uma função pseudo-randômica em elementos de um array que podem ser editados.